// #ifdef FREQUENCY_H
// #define FREQUENCY_H
// #include <iostream>
// #include <fstream>

// using namespace std;
// //void: 리턴값 반환 x, 실수 or 정수형 : 리턴값 반환 o
// class Pr_freq{

//   private:
// int count;
// int size;
// char c;
// int CAPACITY;




//   public:
// void check_file();
// void input_freq(int count, int size);
// void check_num(int count, int size, char c);






// }
// #endif