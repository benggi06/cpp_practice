// #include <iostream>
// #include <fstream>
// using namespace std;



// int main(){
//   const int CAPACITY = 10;
//   int frequencies [CAPACITY] = {0};
  
//   ifstream fin("num.txt");
  
//   int i;
//   int count=0;
//   while (count<10){
//     fin>>i;
//     if (i%2 ==0){
//       cout<<i<<endl;
//     }
//     count+=1;
    
//   }
//   fin.close();
//   return 0;
  
  



  
// }



















// while (true) {
    
//     fin>>i;
//     while(count<size){
      
//       if ( i == frequencies[count]) {

//         num[count] = num[count] + 1;
//       }
//       count+=1;
//     }
    
//     //파일이 끝나면 반복문 종료
//     if (fin.eof()){
//             break; 
//       }
//   }