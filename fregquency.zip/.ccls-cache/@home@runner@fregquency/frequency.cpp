#include <fstream>
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  //데이터 멤버
  int count=0;
  int i;
  int size = 10;
  
  
  //배열
  const int CAPACITY = 10;
  int frequencies [CAPACITY] = {0};
  int num [CAPACITY] = {0};
  ifstream fin("num.txt");//파일 지정
  
  // num.txt 파일 확인
  if (!fin) {
    cout << "파일을 찾을 수 없습니다." << endl;
    return 0;
  }
  
  //배열 속 범위 숫자 입력
  while (count < size) {
    frequencies[count] = count;
    count += 1;
  }
  count=0;
  fin.close();
  //파일 속 텍스트 읽기
  while (count<size){
    int x = frequencies[count]; // 숫자
    
    ifstream fin("num.txt");
    while (!fin.eof()){
      fin>>i; // 파일 읽어오기
      if ( x == i){ //파일의 숫자와 같으면
        num[x]++;  
      }
    }
    fin.close();
    count+=1;
  }

  count=0;

  //출력
  
  cout << "숫자  "
       << "횟수  "
       << "히스토그램" << endl
       << endl;

  while (count < size) {
    int his_count = 0;
    cout << count << setw(4) << num[count] << setw(4);

    //히스토그램
    while (his_count < num[count]) {
      cout << "*";
      his_count += 1;
    }
    cout << endl;
    count += 1;
   }

  return 0;
}