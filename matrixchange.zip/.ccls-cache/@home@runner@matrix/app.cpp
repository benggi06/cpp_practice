#include <iomanip>
#include <iostream>
using namespace std;

//행 행렬 변환 함수
void rowChange(const int originArray[][4], int rowSize, int rowArray[]) {
  int count = 0;

  for (int k = 0; k < 8; k++) {

    if (k < 4) {
      rowArray[k] = originArray[0][k];

    } else if (k > 3) {

      rowArray[k] = originArray[1][count];
      count += 1;
    }
  }
}

//열 행렬 변환 함수
void columnChange(const int originArray[][4], int columnSize,
                  int columnArray[]) {

  int count = 0;

  for (int k = 0; k < 8; k++) {

    if (k % 2 == 0) {
      columnArray[k] = originArray[0][int(k / 2)];

    } else if (k % 2 != 0) {

      columnArray[k] = originArray[1][count];
      count += 1;
    }
  }
}

//원본 행렬 출력함수
void print_origin(const int originArray[][4], int size) {
  for (int i = 0; i < size; i++) {
    cout << endl;
    for (int j = 0; j < 4; j++) {
      if (j == 3) {
        cout << originArray[i][j];
      } else {
        cout << originArray[i][j] << setw(4);
      }
    }
  }
}

void print_matrix(const int change_marix[], int size) {

  for (int i = 0; i < size; i++) {
    cout << change_marix[i] << setw(4);
  }
}

int main() {
  //배열
  int originArray[2][4] = {{0, 1, 2, 3}, {10, 11, 12, 13}};
  int rowArray[8];
  int columnArray[8];

  //선형변환
  rowChange(originArray, 2, rowArray);
  columnChange(originArray, 2, columnArray);

  //원래 행렬출력
  cout << " Original Array " << endl;
  print_origin(originArray, 2);

  cout << endl;
  //행변환 출력
  cout << "Row-Transformed Array: ";
  print_matrix(rowArray, 8);
  cout << endl;
  //열변환 출력
  cout << "Column-Transformed Array: ";
  print_matrix(columnArray, 8);

  return 0;
}
