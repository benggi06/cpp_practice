#include <iomanip>
#include <iostream>
using namespace std;

void rowChange(const int originArray[][4],int rowSize,int rowArray[]) {
  int count=0;
  
  for (int k = 0; k<8; k++){
    
    if (k<4){
      rowArray[k]=originArray[0][k];
      
    }else if (k>3){
      k-=4;
      rowArray[k]=originArray[1][k];
      
    }
    
  }
  
}
void columnChange(const int originArray[][4],int rowSize,int columnArray[]) {
  
  int count=0;
  for (int k = 0; k<8; k++){
    
    if (k % 2 == 0){
      columnArray[k]=originArray[0][k];
      
      
    }else if (k % 2 != 0){
      
      columnArray[k]=originArray[1][k];
      
    }
    
}
  }

int main(){
  int originArray [2][4] = {{0, 1, 2, 3}, {10, 11, 12, 13}};
  int rowArray [8];
  rowChange(originArray, 2, rowArray);
  for (int i = 0; i<8; i++){
    cout<<rowArray[i]<<" ";
  }
  
  
}

  


